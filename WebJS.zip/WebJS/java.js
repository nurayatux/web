
console.log("Yerken Nurayat from group IT-2407");
/*-alert("Hello, JavaScript world!")-*/

let studentName = "Nurayat"; 
let studentAge = 17; 
let hasScholarship= true; 

console.log("Student Name:", studentName);
console.log("Student Age:", studentAge);
console.log("Has scholarship:", hasScholarship);

let x = 7;
let y = 5;

console.log("x = " + x + "      y = " + y);
console.log("Addition:", x + y);
console.log("Subtraction:", x - y);
console.log("Multiplication:", x * y);
console.log("Division:", x / y);
console.log("Remainder:", x % y);

let greetingMessage = "My name is " + studentName + " and i'm " + studentAge + " years old.";
console.log(greetingMessage);

function changeText() {
  document.getElementById("paragraph").innerText =
    "Enhypen World game is aviable now!";
}

function changeColor() {
  let box = document.getElementById("box");
  box.style.backgroundColor = "lightblue";
}

function changeFontSize() {
  let box = document.getElementById("box");
  box.style.fontSize = "30px";
}

function addItem() {
  let list = document.getElementById("itemList");
  let newItem = document.createElement("li");
  newItem.textContent = "item " + (list.children.length + 1);
  list.appendChild(newItem);
}

function removeItem() {
  let list = document.getElementById("itemList");
  if (list.lastElementChild) {
    list.removeChild(list.lastElementChild);
  }
}

function hoverOn() {
  const box = document.getElementById("mouseEvent");
  box.style.backgroundColor = "#d961cfc2"; 
  box.style.borderColor = "#1b5fbf";
  box.style.width = "200px";
}

function hoverOff() {
  const box = document.getElementById("mouseEvent");
  box.style.backgroundColor = "#ffffffff"; 
  box.style.borderColor = "#000000ff";
  box.style.width = "200px";
}

function mirrorInput() {
  const value = document.getElementById("liveInput").value;
  document.getElementById("liveValue").textContent = value || "Live value";
}

function validateForm() {
  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();
  const errorBox = document.getElementById("formError");

  errorBox.textContent = "";

  if (!name || !email || !password) {
    errorBox.textContent = "Please fill in all fields (Name, Email, Password).";
    return false;
  }

  if (password.length < 8) {
    errorBox.textContent = "Password must be at least 8 characters.";
    return false;
  }

  const simpleEmailPattern = /^\S+@\S+\.\S+$/;
  if (!simpleEmailPattern.test(email)) {
    errorBox.textContent = "Please enter a valid email address.";
    return false;
  }

  errorBox.textContent = "Form looks good!";
  errorBox.classList.add("ok");
  return false;
}

const tasks = [];
  let nextId = 1;

  const todoInput = document.getElementById("todoInput");
  const addTaskBtn = document.getElementById("addTaskBtn");
  const todoList = document.getElementById("todoList");
  const todoInfo = document.getElementById("todoInfo");

  addTaskBtn.addEventListener("click", addTask);
  todoInput.addEventListener("keyup", (e) => {
    if (e.key === "Enter") addTask();
  });

  function addTask() {
    const text = todoInput.value.trim();
    if (!text) return;
    tasks.push({ id: nextId++, text, done: false });
    todoInput.value = "";
    renderTasks();
  }

  function toggleTask(id) {
    const task = tasks.find(t => t.id === id);
    if (task) task.done = !task.done;
    renderTasks();
  }

  function deleteTask(id) {
    const index = tasks.findIndex(t => t.id === id);
    if (index >= 0) tasks.splice(index, 1);
    renderTasks();
  }

  function renderTasks() {
  todoList.innerHTML = "";

  tasks.forEach(t => {
    const li = document.createElement("li");

    const left = document.createElement("div");
    left.className = "task" + (t.done ? " done" : "");

    const cb = document.createElement("input");
    cb.type = "checkbox";
    cb.checked = t.done;
    cb.addEventListener("change", () => toggleTask(t.id));

    const label = document.createElement("label");
    label.textContent = t.text;

    left.appendChild(cb);
    left.appendChild(label);

    const delBtn = document.createElement("button");
    delBtn.textContent = "Delete";
    delBtn.className = "deleteBtn";
    delBtn.addEventListener("click", () => deleteTask(t.id));

    li.appendChild(left);
    li.appendChild(delBtn);
    todoList.appendChild(li);
  });

  const total = tasks.length;
  const completed = tasks.filter(t => t.done).length;
  todoInfo.textContent = `${total} task${total !== 1 ? "s" : ""} • ${completed} completed`;
}

renderTasks();
