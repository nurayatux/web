
$(document).ready(function() {
    //task 0
    console.log("jQuery is ready!");

    //task 1
    $("#p1").text("Text changed using .text() for ID selector.");
    $(".text").html("Text changed using .html() for class selector.");
    /*-$("div").css({
        "background-color": "lightgreen",
        "padding": "10px",
        "border-radius": "8px"
    });
    $("p").addClass("highlight");-*/

    //task 2
        $("#hideBtn").click(function() {
        $("#message").hide();
    });
    $("#showBtn").click(function() {
        $("#message").show();
    });
    $("#toggleBtn").click(function() {
        $("#message").toggle();
    });

    //task 3
    $("#fadeInBtn").click(function() {
        $("#image").fadeIn(1000);
    });
    $("#fadeOutBtn").click(function() {
        $("#image").fadeOut(1000);
    });
    $("#fadeToggleBtn").click(function() {
        $("#image").fadeToggle(1000);
    });

    //task 4
    $("#slideDownBtn").click(function() {
    $("#panel").slideDown(800);
    });

    $("#slideUpBtn").click(function() {
        $("#panel").slideUp(800);
    });
    $("#slideToggleBtn").click(function() {
        $("#panel").slideToggle(800);
    });

    //task 5
    let count = 3;
    $("#addBtn").click(function() {
        $("#itemList").append("<li>Item " + count + " (new)</li>");
        count++;
    });
    $("#prependBtn").click(function() {
        $("#itemList").prepend("<li>Item " + count + " (new)</li>");
        count++;
    });
    $("#removeBtn").click(function() {
        $("#itemList li:last-child").remove();
     });

     //task 6
    $("#changeImageBtn").click(function() {
        $("#cat").attr("src", "images/img2.jpg");
    });
    $("#changeLinkBtn").click(function() {
        $("#myLink")
        .attr("href", "https://www.youtube.com/")
        .text("Go to Youtube");
    });

    //task 7
    $("#name").on("keyup", function() {
        let nameValue = $(this).val();
        $("#displayName").text(nameValue);
    });
    $("#email").on("keyup", function() {
        let emailValue = $(this).val();
        $("#displayEmail").text(emailValue);
    });
    /*-
    //task 8
    $("#animateBtn").click(function() {
    $("#box").animate({
        left: "200px",
        width: "200px",
        height: "200px",
        }, 1000);
    });
    $("#resetBtn").click(function() {
        $("#box").animate({
        left: "0px",
        width: "100px",
        height: "100px",
        }, 1000);
    });

    //task 9
    function resetBox() {
    $("#box").stop(true, true).css({
        left: 0,
        top: 0,
        width: "100px",
        height: "100px",
        opacity: 1
        });
    }
    resetBox();
    $("#startBtn").on("click", function () {
        $("#box").stop(true, true)
        .animate({ left: "+=200px" }, 600)
        .animate({ top: "+=200px" }, 600)
        .animate({ width: "60px", height: "60px", opacity: 0.7 }, 500)
        .animate({ left: 0, top: 0, width: "100px", height: "100px", opacity: 1 }, 700);
    });
    $("#resetBtn").on("click", resetBox);
    $("#stopBtn").on("click", function () {
        $("#box").stop(false, false);
    });-*/

    //task 10
    $(function () {
    function resetBox() {
        $("#box").stop(true, true).css({
        left: 0,
        top: 0,
        width: "100px",
        height: "100px",
        opacity: 1
        });
    }
    resetBox();
    $("#animateBtn").on("click", function () {
        $("#box").animate({
        left: "250px",
        top: "120px",
        width: "200px",
        height: "200px",
        }, 1000);
    });
    $("#resetBtn").on("click", resetBox);
    });

    //task 11
    $(".thumb").hide().each(function(index) {
        $(this).delay(200 * index).fadeIn(500);
    });

    $(".thumb").click(function() {
        let src = $(this).attr("src");
        $("#mainImage")
        .attr("src", src)
        .hide()
        .fadeIn(600);
    });
    $("#hideGallery").click(function() {
        $(".thumb").fadeOut(600);
        $("#mainImage").fadeOut(600);
    });
    $("#showGallery").click(function() {
        $(".thumb").fadeIn(600);
    });
});